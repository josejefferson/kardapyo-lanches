<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{
    public function index()
    {
        return redirect('/admin/products');
    }
    
    public function seed()
    {
        Artisan::call('db:seed');
        Session::flash('success', 'Banco de dados resetado com sucesso!');
        return redirect('/admin/products');
    }
}
