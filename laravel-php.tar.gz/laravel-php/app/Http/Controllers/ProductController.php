<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreProductRequest;
use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\Session;

class ProductController extends Controller
{
    public function getAll()
    {
        $products = Product::orderBy('updated_at', 'desc')->get();
        return view('home', ['products' => $products]);
    }

    public function search(Request $request)
    {
        $search = $request->query('q');
        $products = Product::where('name', 'LIKE', '%' . $search . '%')->orderBy('updated_at', 'desc')->get();
        return view('search', ['products' => $products, 'search' => $search]);
    }

    public function getOne(string $id)
    {
        $product = Product::find($id);

        if ($product) {
            return view('product', ['product' => $product]);
        } else {
            return abort(404, 'Este produto não existe');
        }
    }

    public function login()
    {
        $products = Product::orderBy('updated_at', 'desc')->get();
        return view('login', ['products' => $products]);
    }

    public function list()
    {
        $products = Product::orderBy('updated_at', 'desc')->get();
        return view('products', ['products' => $products]);
    }

    public function createView()
    {
        return view('product-edit');
    }

    public function create(StoreProductRequest $request)
    {
        $product = Product::create($request->all());
        Session::flash('success', "Produto \"{$product->name}\" criado com sucesso!");
        return redirect('/admin/products');
    }

    public function editView(string $id)
    {
        $product = Product::find($id);

        if ($product) {
            return view('product-edit', ['product' => $product]);
        } else {
            Session::flash('error', 'Este produto não existe!');
            return redirect('/admin/products');
        }
    }

    public function edit(StoreProductRequest $request, string $id)
    {
        $product = Product::find($id);

        if ($product) {
            $product->update($request->all());
            Session::flash('success', "Produto \"{$product->name}\" editado com sucesso!");
        } else {
            Session::flash('error', 'Não foi possível editar pois o produto não existe!');
        }

        return redirect('/admin/products');
    }

    public function delete(string $id)
    {
        $product = Product::find($id);

        if ($product) {
            $product->delete();
            Session::flash('success', "Produto \"{$product->name}\" excluído com sucesso!");
        } else {
            Session::flash('warning', 'O produto não existe!');
        }

        return redirect('/admin/products');
    }
}
