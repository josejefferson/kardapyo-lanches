<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        
        $products = [
            [
                'name' => 'Coca-Cola',
                'description' => 'Para acompanhar o seu lanche',
                'price' => 3.99,
                'image' => 'https://files.sunoresearch.com.br/n/uploads/2023/04/coca-cola-resultados-1t23.jpg'
            ],
            [
                'name' => 'Coxinha de Frango',
                'description' => 'A melhor da região',
                'price' => 2.99,
                'image' => 'https://kyodai.com.br/wp-content/uploads/2018/07/cox_grande_kyodai_2-1.jpeg'
            ],
            [
                'name' => 'Pastel de Carne',
                'description' => 'Um delicioso e crocante pastel de carne',
                'price' => 4.49,
                'image' => 'https://www.estadao.com.br/resizer/v2/OYMESDUUBVJJDBXTFC4YD253O4.jpg?quality=80&auth=288974b5d339d197eb843c3578f77fbd34d131698ef6c702cab28d092c61658a&width=720&height=503&smart=true'
            ]
        ];

        DB::table('products')->truncate();
        DB::table('products')->insert($products);
    }
}
