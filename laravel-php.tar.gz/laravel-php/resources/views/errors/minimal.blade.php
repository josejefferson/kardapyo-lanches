@extends('layouts.main')

@section('content')
    <main class="container px-4 mt-8 mx-auto max-w-6xl text-center">
        <i class="fa-solid fa-triangle-exclamation text-8xl"></i>

        <h1 class="text-3xl font-thin my-4">
            @yield('code') @yield('message')
        </h1>
        <p>
            {{ $exception->getMessage() }}
        </p>
    </main>
@endsection
