<!DOCTYPE html>
<html lang="pt-BR" data-theme="light">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="/static/img/favicon.png" type="image/png" />
    <title>
        @hasSection('title')
            @yield('title') | Kardapyo Lanches | Cardápio Digital Online
        @else
            Kardapyo Lanches | Cardápio Digital Online
        @endif
    </title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.11.1/dist/full.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <link rel="stylesheet" href="/static/css/global.css" />
    <link rel="stylesheet" href="/static/css/index.css" />
</head>

<body>
    @include('partials.toasts')
    @include('partials.navbar')
    @yield('content')
    @include('partials.footer')
</body>

</html>
