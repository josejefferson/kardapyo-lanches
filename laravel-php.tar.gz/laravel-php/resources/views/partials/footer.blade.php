<!-- Rodapé -->
<div class="bg-base-200">
    <footer class="footer p-10 text-base-content mt-8 container mx-auto max-w-6xl">
        <aside>
            <img src="/static/img/logo.svg" alt="Logo" class="h-10" />
            <p>
                Kardapyo Lanches
                <br />
                Desenvolvido por Jefferson Dantas
                <br />
                <br />
                <b>Este site é apenas um design,<br />
                    não se trata de um comércio real</b>
            </p>
        </aside>
        <nav>
            <h6 class="footer-title">Redes sociais</h6>
            <a class="link link-hover"><i class="fa-fw fa-brands fa-instagram"></i> Instagram</a>
            <a class="link link-hover"><i class="fa-fw fa-brands fa-facebook"></i> Facebook</a>
            <a class="link link-hover"><i class="fa-fw fa-brands fa-youtube"></i> YouTube</a>
            <a class="link link-hover"><i class="fa-fw fa-brands fa-x-twitter"></i> Twitter (X)</a>
        </nav>
        <nav>
            <h6 class="footer-title">Empresa</h6>
            <a target="_blank" href="https://jeffersondantas.vercel.app" class="link link-hover">Sobre nós</a>
            <a target="_blank" href="https://www.linkedin.com/in/jose-jefferson" class="link link-hover">Contato</a>
            <a target="_blank" href="https://github.com/josejefferson" class="link link-hover">GitHub</a>
            <a target="_blank" href="https://github.com/josejefferson/kardapyo" class="link link-hover">Código Fonte</a>
        </nav>
        <nav>
            <h6 class="footer-title">Legal</h6>
            <a class="link link-hover">Termos de Uso</a>
            <a class="link link-hover">Política de Privacidade</a>
            <a class="link link-hover">Política de Cookies</a>
        </nav>
    </footer>
</div>
