<!-- NavBar -->
<nav class="navbar bg-base-100">
    <div class="container mx-auto max-w-6xl">
        <!-- Título -->
        <div class="flex-1">
            <a href="/" class="btn btn-ghost text-xl">
                <img src="/static/img/logo.svg" alt="Logo" class="h-10" />
            </a>
        </div>

        <div class="flex gap-2 items-center">
            <!-- Pesquisa -->
            <form action="/search" method="GET">
                <label class="input input-bordered flex items-center gap-2 h-10 w-36 md:w-auto">
                    <input type="text" name="q" placeholder="Pesquisar..." class="search w-full" required
                        {{-- #if
            search}}value="{{search}}" autofocus{{/if --}} />
                    <button type="submit" class="fa-solid fa-magnifying-glass"></button>
                </label>
            </form>

            <!-- Perfil -->
            {{-- #if user --}}
            <div class="dropdown dropdown-end">
                <div class="avatar placeholder" tabindex="0" role="button">
                    <div class="bg-neutral text-neutral-content rounded-full w-10">
                        <span>{{-- userInitials user.name --}}</span>
                    </div>
                </div>

                <!-- Dropdown perfil -->
                <ul tabindex="0"
                    class="mt-3 z-[1] p-2 shadow menu menu-sm dropdown-content bg-base-100 rounded-box w-52">
                    <li><a href="/admin">Administração</a></li>
                    <li>
                        <form action="/logout" method="POST" class="block p-0">
                            <input type="hidden" name="_csrf" value="{{-- @root.csrf --}}">
                            <button type="submit" class="w-full text-left px-3 py-1">
                                Sair
                            </button>
                        </form>
                    </li>
                </ul>
                {{-- else --}}
                <a href="/login" class="btn btn-ghost btn-sm">Entrar</a>
                {{-- /if --}}
            </div>
        </div>
    </div>
</nav>
<div class="detalhe"></div>
