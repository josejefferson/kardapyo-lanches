<a href="/product/{{ $product->id }}" class="card bg-base-100 shadow-xl">
    <figure>
        <img class="object-cover w-full h-44" src="{{ $product->image }}" />
    </figure>
    <div class="card-body p-6">
        <h2 class="card-title">
            {{ $product->name }}
            @if (strtotime($product->created_at) > strtotime('-1 day'))
                <div class="badge badge-secondary">NOVO</div>
            @endif
        </h2>
        <p>{{ $product->description }}</p>
        <div class="font-bold">R$ {{ number_format($product->price, 2, ',', '.') }}</div>
        <div class="rating rating-xs">
            <input type="radio" name="rating-{{ $product->id }}" class="mask mask-star-2 bg-orange-400" />
            <input type="radio" name="rating-{{ $product->id }}" class="mask mask-star-2 bg-orange-400" />
            <input type="radio" name="rating-{{ $product->id }}" class="mask mask-star-2 bg-orange-400" />
            <input type="radio" name="rating-{{ $product->id }}" class="mask mask-star-2 bg-orange-400" checked />
            <input type="radio" name="rating-{{ $product->id }}" class="mask mask-star-2 bg-orange-400" />
        </div>
    </div>
</a>
