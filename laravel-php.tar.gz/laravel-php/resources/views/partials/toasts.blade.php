<div class="toast toast-top toast-end z-[1]">
    @if (Session::has('success'))
        <input type="radio" class="toast-close" id="success">
        <div class="toast-item alert alert-success min-w-md max-w-md text-white">
            <div class="shrink-0 fa-solid fa-circle-info text-xl"></div>
            <span class="whitespace-normal">{{ Session::get('success') }}</span>
            <label for="success" class="shrink-0 btn btn-square btn-ghost btn-sm" tabindex="0">
                <i class="fa-solid fa-close text-xl"></i>
            </label>
        </div>
    @endif

    @if (Session::has('error'))
        <input type="radio" class="toast-close" id="error">
        <div class="toast-item alert alert-error min-w-md max-w-md text-white">
            <div class="shrink-0 fa-solid fa-circle-info text-xl"></div>
            <span class="whitespace-normal">{{ Session::get('error') }}</span>
            <label for="error" class="shrink-0 btn btn-square btn-ghost btn-sm" tabindex="0">
                <i class="fa-solid fa-close text-xl"></i>
            </label>
        </div>
    @endif

    @if (Session::has('warning'))
        <input type="radio" class="toast-close" id="warning">
        <div class="toast-item alert alert-warning min-w-md max-w-md text-white">
            <div class="shrink-0 fa-solid fa-circle-info text-xl"></div>
            <span class="whitespace-normal">{{ Session::get('warning') }}</span>
            <label for="warning" class="shrink-0 btn btn-square btn-ghost btn-sm" tabindex="0">
                <i class="fa-solid fa-close text-xl"></i>
            </label>
        </div>
    @endif

    @if (Session::has('info'))
        <input type="radio" class="toast-close" id="info">
        <div class="toast-item alert alert-info min-w-md max-w-md text-white">
            <div class="shrink-0 fa-solid fa-circle-info text-xl"></div>
            <span class="whitespace-normal">{{ Session::get('info') }}</span>
            <label for="info" class="shrink-0 btn btn-square btn-ghost btn-sm" tabindex="0">
                <i class="fa-solid fa-close text-xl"></i>
            </label>
        </div>
    @endif

    @if ($errors->any())
        <input type="radio" class="toast-close" id="validation-error">
        <div class="toast-item alert alert-error min-w-md max-w-md text-white">
            <div class="shrink-0 fa-solid fa-circle-info text-xl"></div>
            <ul>
                <li>
                    <div class="font-bold">Erro de validação</div>
                </li>
                @foreach ($errors->all() as $error)
                    <li>
                        <span class="whitespace-normal">{{ $error }}</span>
                    </li>
                @endforeach
            </ul>
            <label for="validation-error" class="shrink-0 btn btn-square btn-ghost btn-sm" tabindex="0">
                <i class="fa-solid fa-close text-xl"></i>
            </label>
        </div>
    @endif
</div>
