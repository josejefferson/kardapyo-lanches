@extends('layouts.main')

@section('content')
    <main class="container px-4 mt-8 mx-auto max-w-6xl">
        <div class="grid gap-12 grid-cols-1 md:grid-cols-2">
            <!-- Imagem -->
            <figure>
                <img class="object-cover w-full" src="{{ $product->image }}" />
            </figure>

            <!-- Detalhes -->
            <div>
                <h1 class="text-5xl font-thin mb-6">{{ $product->name }}</h1>

                <div class="rating mb-6">
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" checked />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                </div>

                <p>{{ $product->description }}</p>

                <div class="text-2xl font-medium mt-4">R$ {{number_format($product->price, 2, ',', '.')}}</div>

                <button class="btn btn-lg btn-primary mt-6">
                    <i class="fa-solid fa-cart-shopping"></i>
                    Entre em Contato para Comprar
                </button>
            </div>
        </div>
    </main>
@endsection
