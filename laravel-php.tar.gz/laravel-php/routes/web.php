<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [ProductController::class, 'getAll']);
Route::get('/search', [ProductController::class, 'search']);
Route::get('/product/{id}', [ProductController::class, 'getOne']);
Route::get('/login', [ProductController::class, 'login']);
Route::post('/login');
Route::post('/logout');
Route::get('/admin', [AdminController::class, 'index']);
Route::get('/admin/products', [ProductController::class, 'list']);
Route::get('/admin/products/create', [ProductController::class, 'createView']);
Route::post('/admin/products', [ProductController::class, 'create']);
Route::get('/admin/products/edit/{id}', [ProductController::class, 'editView']);
Route::put('/admin/products/{id}', [ProductController::class, 'edit']);
Route::delete('/admin/products/{id}', [ProductController::class, 'delete']);
Route::get('/admin/seed', [AdminController::class, 'seed']);
