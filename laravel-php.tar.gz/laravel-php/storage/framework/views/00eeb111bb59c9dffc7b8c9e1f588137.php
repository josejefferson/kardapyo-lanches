<?php $__env->startSection('content'); ?>
    <main class="container px-4 mt-8 mx-auto max-w-6xl text-center">
        <i class="fa-solid fa-triangle-exclamation text-8xl"></i>

        <h1 class="text-3xl font-thin my-4">
            <?php echo $__env->yieldContent('code'); ?> <?php echo $__env->yieldContent('message'); ?>
        </h1>
        <p>
            <?php echo e($exception->getMessage()); ?>

        </p>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/errors/minimal.blade.php ENDPATH**/ ?>