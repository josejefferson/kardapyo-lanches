<?php $__env->startSection('content'); ?>
    <!-- Produtos -->
    <main class="container px-4 mt-8 mx-auto max-w-6xl">
        <h1 class="text-5xl font-thin mb-8">Resultados para "<?php echo e($search); ?>"</h1>

        <div class="grid gap-4 grid-cols-1 sm:grid-cols-3 lg:grid-cols-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.product', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/search.blade.php ENDPATH**/ ?>