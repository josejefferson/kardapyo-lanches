<?php $__env->startSection('content'); ?>
    <!-- Produtos -->
    <main class="overflow-x-auto container px-4 mt-8 mx-auto max-w-6xl">
        <h1 class="text-5xl font-thin mb-8">Gerenciar cardápio</h1>

        <?php if(count($products)): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th class="w-0">
                            <div class="tooltip tooltip-right" data-tip="Adicionar produto">
                                <a href="/admin/products/create" class="btn btn-primary btn-square btn-sm">
                                    <i class="fa-solid fa-add"></i>
                                </a>
                            </div>
                        </th>
                        <th class="w-0">Imagem</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th class="w-0">Avaliação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div class="flex gap-1 flex-col md:flex-row">
                                    <div class="tooltip" data-tip="Editar">
                                        <a href="/admin/products/edit/<?php echo e($product->id); ?>"
                                            class="btn btn-sm btn-square btn-outline btn-primary">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>
                                    </div>
                                    <div class="tooltip" data-tip="Excluir">
                                        <label for="delete-modal-<?php echo e($product->id); ?>"
                                            class="btn btn-sm btn-square btn-outline btn-error" tabindex="0">
                                            <i class="fa-solid fa-trash"></i>
                                        </label>
                                    </div>
                                </div>
                            </td>

                            <td>
                                <img class="mask mask-squircle w-12 h-12 object-cover" src="<?php echo e($product->image); ?>" />
                            </td>

                            <td>
                                <div class="font-bold"><?php echo e($product->name); ?></div>
                                <div class="text-sm opacity-50">R$ <?php echo e(number_format($product->price, 2, ',', '.')); ?></div>
                            </td>

                            <td><?php echo e($product->description); ?></td>

                            <td>
                                <div class="rating">
                                    <input type="radio" name="rating-<?php echo e($product->id); ?>"
                                        class="mask mask-star-2 bg-orange-400" />
                                    <input type="radio" name="rating-<?php echo e($product->id); ?>"
                                        class="mask mask-star-2 bg-orange-400" />
                                    <input type="radio" name="rating-<?php echo e($product->id); ?>"
                                        class="mask mask-star-2 bg-orange-400" />
                                    <input type="radio" name="rating-<?php echo e($product->id); ?>"
                                        class="mask mask-star-2 bg-orange-400" checked />
                                    <input type="radio" name="rating-<?php echo e($product->id); ?>"
                                        class="mask mask-star-2 bg-orange-400" />
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.product-delete', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-center text-gray-400 my-32">
                <i class="fa-solid fa-pizza-slice text-9xl"></i>
                <h1 class="text-3xl font-medium my-6">Não há produtos</h1>
                <a href="/admin/products/create" class="btn btn-primary btn-outline">
                    <i class="fa-solid fa-add"></i> Adicionar produto
                </a>
            </div>
        <?php endif; ?>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/products.blade.php ENDPATH**/ ?>