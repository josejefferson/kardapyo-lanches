<?php $__env->startSection('content'); ?>
    <main class="container px-4 mt-8 mx-auto max-w-6xl">
        <div class="grid gap-12 grid-cols-1 md:grid-cols-2">
            <!-- Imagem -->
            <figure>
                <img class="object-cover w-full" src="<?php echo e($product->image); ?>" />
            </figure>

            <!-- Detalhes -->
            <div>
                <h1 class="text-5xl font-thin mb-6"><?php echo e($product->name); ?></h1>

                <div class="rating mb-6">
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" checked />
                    <input type="radio" name="rating-2" class="mask mask-star-2 bg-orange-400" />
                </div>

                <p><?php echo e($product->description); ?></p>

                <div class="text-2xl font-medium mt-4">R$ <?php echo e(number_format($product->price, 2, ',', '.')); ?></div>

                <button class="btn btn-lg btn-primary mt-6">
                    <i class="fa-solid fa-cart-shopping"></i>
                    Entre em Contato para Comprar
                </button>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/product.blade.php ENDPATH**/ ?>