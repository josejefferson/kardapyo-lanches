<?php $__env->startSection('content'); ?>
    <main class="container px-4 mt-8 mx-auto max-w-6xl">
        <?php if(isset($product)): ?>
            <h1 class="text-5xl font-thin mb-8">Editar produto "<?php echo e($product->name); ?>"</h1>

            <label for="delete-modal-<?php echo e($product->id); ?>" class="btn btn-error btn-outline mb-8" tabindex="0">
                <i class="fa-solid fa-trash"></i> Excluir produto
            </label>

            <?php echo $__env->make('partials.product-delete', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <h1 class="text-5xl font-thin mb-8">Adicionar novo produto</h1>
        <?php endif; ?>

        <form action="/admin/products/<?php echo e($product->id ?? ''); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php if(isset($product)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>
            <label class="form-control w-full mb-4">
                <div class="label font-bold">
                    <span class="label-text">Nome</span>
                </div>
                <input type="text" name="name" class="input input-bordered w-full"
                    value="<?php echo e(old('name') ?? ($product->name ?? '')); ?>" required autofocus />
            </label>

            <label class="form-control w-full mb-4">
                <div class="label font-bold">
                    <span class="label-text">Descrição</span>
                </div>
                <textarea name="description" class="textarea textarea-bordered w-full" required><?php echo e(old('description') ?? ($product->description ?? '')); ?></textarea>
            </label>

            <label class="form-control w-full mb-4">
                <div class="label font-bold">
                    <span class="label-text">Preço</span>
                </div>
                <label class="input input-bordered flex items-center gap-2">
                    R$
                    <input type="number" min="0" step="0.01" class="grow" name="price"
                        value="<?php echo e(old('price') ?? ($product->price ?? '')); ?>" required />
                </label>
            </label>

            <label class="form-control w-full mb-4">
                <div class="label font-bold">
                    <span class="label-text">URL da imagem</span>
                </div>
                <input type="url" name="image" class="input input-bordered w-full"
                    value="<?php echo e(old('image') ?? ($product->image ?? '')); ?>" required />
            </label>

            <button type="submit" class="btn btn-primary">
                <i class="fa-solid fa-floppy-disk"></i> Salvar
            </button>
        </form>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/product-edit.blade.php ENDPATH**/ ?>