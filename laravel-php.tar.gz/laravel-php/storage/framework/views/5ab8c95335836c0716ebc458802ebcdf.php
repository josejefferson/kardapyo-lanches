<a href="/product/<?php echo e($product->id); ?>" class="card bg-base-100 shadow-xl">
    <figure>
        <img class="object-cover w-full h-44" src="<?php echo e($product->image); ?>" />
    </figure>
    <div class="card-body p-6">
        <h2 class="card-title">
            <?php echo e($product->name); ?>

            <?php if(strtotime($product->created_at) > strtotime('-1 day')): ?>
                <div class="badge badge-secondary">NOVO</div>
            <?php endif; ?>
        </h2>
        <p><?php echo e($product->description); ?></p>
        <div class="font-bold">R$ <?php echo e(number_format($product->price, 2, ',', '.')); ?></div>
        <div class="rating rating-xs">
            <input type="radio" name="rating-<?php echo e($product->id); ?>" class="mask mask-star-2 bg-orange-400" />
            <input type="radio" name="rating-<?php echo e($product->id); ?>" class="mask mask-star-2 bg-orange-400" />
            <input type="radio" name="rating-<?php echo e($product->id); ?>" class="mask mask-star-2 bg-orange-400" />
            <input type="radio" name="rating-<?php echo e($product->id); ?>" class="mask mask-star-2 bg-orange-400" checked />
            <input type="radio" name="rating-<?php echo e($product->id); ?>" class="mask mask-star-2 bg-orange-400" />
        </div>
    </div>
</a>
<?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/partials/product.blade.php ENDPATH**/ ?>