<?php $__env->startSection('content'); ?>
    <!-- Banner -->
    <div class="banner text-white mt-6">
        <div class="bg-black/50">
            <div class="container px-4 mx-auto max-w-6xl py-10 md:py-20">
                <h1 class="text-5xl font-semibold mb-8">Os melhores Lanches, você encontra aqui!</h1>
                <h2 class="text-2xl font-thin mb-8 md:mb-14">Variedade e qualidade que só a gente tem!</h2>
                <a href="#cardapio" class="btn btn-primary">VEJA O NOSSO CARDÁPIO</a>
            </div>
        </div>
    </div>

    <!-- Produtos -->
    <main id="cardapio" class="container px-4 mt-8 mx-auto max-w-6xl">
        <h1 class="text-5xl font-thin mb-8">Nosso cardápio</h1>

        <div class="grid gap-4 grid-cols-1 sm:grid-cols-3 lg:grid-cols-4">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('partials.product', ['product' => $product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/home.blade.php ENDPATH**/ ?>