<input type="checkbox" id="delete-modal-<?php echo e($product->id); ?>" class="modal-toggle" />
<div class="modal" role="dialog">
    <div class="modal-box">
        <h3 class="font-bold text-lg">Excluir "<?php echo e($product->name); ?>"</h3>
        <p class="py-4">Tem certeza que deseja excluir o produto "<?php echo e($product->name); ?>"?</p>
        <div class="modal-action">
            <form action="/admin/products/<?php echo e($product->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-error">Sim</button>
            </form>
            <label for="delete-modal-<?php echo e($product->id); ?>" class="btn">Não</label>
        </div>
    </div>
</div>
<?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/partials/product-delete.blade.php ENDPATH**/ ?>