<?php $__env->startSection('content'); ?>
    <main class="hero bg-base-200 mt-8" style="background-image: url(/static/img/banner.jpg)">
        <div class="hero-overlay bg-opacity-60"></div>
        <div class="hero-content gap-8 flex-col lg:flex-row-reverse container px-4 py-16 mx-auto max-w-6xl">
            <div class="text-center lg:text-left text-white">
                <h1 class="text-5xl font-bold">Bem-vindo!</h1>

                <p class="py-6 text-xl">Faça login para gerenciar nosso delicioso cardápio.</p>

                <div class="carousel rounded-box h-32 max-w-96 d-none hidden lg:inline-flex">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="carousel-item">
                            <img src="<?php echo e($product->image); ?>" alt="<?php echo e($product->name); ?>" />
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="card shrink-0 w-full max-w-sm shadow-2xl bg-base-100">
                <form action="/login" method="POST" class="card-body">
                    <?php echo csrf_field(); ?>
                    <label class="form-control">
                        <div class="label font-bold">
                            <span class="label-text">E-mail</span>
                        </div>
                        <input type="email" name="email" placeholder="Digite seu E-mail" class="input input-bordered"
                            autofocus required />
                    </label>
                    <label class="form-control">
                        <div class="label font-bold">
                            <span class="label-text">Senha</span>
                        </div>
                        <input type="password" name="password" placeholder="Digite sua Senha" class="input input-bordered"
                            required />
                        <label class="label">
                            <a href="#" class="label-text-alt link link-hover">Esqueceu sua senha?</a>
                        </label>
                    </label>
                    <div class="form-control mt-6">
                        <button type="submit" class="btn btn-primary">ENTRAR</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jeffersonn_jjdaj/www/kardapyo/laravel-php/resources/views/login.blade.php ENDPATH**/ ?>